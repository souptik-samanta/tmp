## Description

If you're suggesting a new feature then just a description will suffice.

- [ ] Does this issue still occur in the master branch? (**Required if issue**)


#### Neofetch version

## Screenshot

## Config file

## Verbose log

1. Run `neofetch -vv 2> neofetchlog`
2. Upload the contents of `neofetchlog` to pastebin, gist or equivalent.



